from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor

#Creates the window
window = Tk()
window.title("Car price predictor")


def __init__(self):
    self.dataSet = pd.read_csv('new_car_price_prediction')

    self.x = self.dataSet.drop('Price', axis=1).values
    self.y = self.dataSet['Price'].values
def pricePrediction():
    predictors =['Category','Fuel type','Prod. year']
    import pickle
    with open('finalXBGModel.pkl', 'rb') as fileReadStream:
            predictionModel = pickle.load(fileReadStream)
            fileReadStream.close()

    cat = categoryInput.get()
    fuel = fuelTypeInput.get()
    prody = prodYearInput.get()

    df = pd.DataFrame(data=[[float(cat), float(fuel), float(prody)]], columns=['Category', 'Fuel type', 'Prod. year'])
    print(predictionModel.predict(df[predictors].values))
    priceNo.set(predictionModel.predict(df[predictors].values))




#Creating buttons and placing them
label01 = Label(window, text="Input the category number:")
label01.grid(row=0, column=0)

label02 = Label(window, text="Input the fuel type number:")
label02.grid(row=0, column=2)

label03 = Label(window, text="Input the production year:")
label03.grid(row=0, column=1)

categoryInput = StringVar()
entry01 = Entry(window, textvariable=categoryInput)
entry01.grid(row=1,column=0)

fuelTypeInput = StringVar()
entry02 = Entry(window, textvariable=fuelTypeInput)
entry02.grid(row=1,column=2)

prodYearInput = StringVar()
entry03 = Entry(window, textvariable=prodYearInput)
entry03.grid(row=1,column=1)

priceNo = StringVar()
calcBtn = Button(window, text="Calculate the price", command=pricePrediction)
calcBtn.grid(row=5, column=1)

entry04 = Entry(window, state="readonly", textvariable=priceNo)
entry04.grid(row=6, column=1)

#keeps window running
window.mainloop()